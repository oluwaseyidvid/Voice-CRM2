package com.neuralic.voicecrm

class MainActivity {}